package com.example.board2.util;

import org.springframework.stereotype.Service;

@Service
public class MyUtil {
	
}
