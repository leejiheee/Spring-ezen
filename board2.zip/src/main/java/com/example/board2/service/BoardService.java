package com.example.board2.service;

public interface BoardService {

}
